const CACHE='papota-v1';
self.addEventListener('install',e=>{self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(self.clients.claim())});
self.addEventListener('fetch',e=>{
  const req=e.request;
  if(req.method!=='GET') return;
  e.respondWith((async()=>{
    const cache=await caches.open(CACHE);
    const hit=await cache.match(req);
    const net=fetch(req).then(r=>{ if(r && r.status===200 && (r.type==='basic'||r.type==='cors')) cache.put(req,r.clone()); return r; }).catch(()=>hit);
    return hit||net;
  })());
});